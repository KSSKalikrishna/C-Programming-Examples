#include<stdio.h>
void main(){
    int a[2][3],i,j,n1,n2;
    for(i=0;i<2;i++){
        for(j=0;j<3;j++){
            printf("enter the elements:");
        scanf("%d",&a[i][j]);
    }
    }
    while(1){
    n1==i;
    n2==j;
   printf("enter the n1:");
    scanf("%d",&n1);
     printf("enter the n2:");
     scanf("%d",&n2);
     printf("Element is :%d\n",a[n1][n2]);
    }
     
    
    
}