#include<stdio.h>
void main(){
    int a[5],b[5],c[5],i;
    for(i=0;i<5;i++){
        printf("enter the numbers for a:");
        scanf("%d",&a[i]);
    }
        for(i=0;i<5;i++){
        printf("enter the numbers for b:");
        scanf("%d",&b[i]);
     }
     for(i=0;i<5;i++){ 
     c[i]=a[i]+b[i];
     printf("index of the array:%d %d\n",i,c[i]);
    }
     

     
}