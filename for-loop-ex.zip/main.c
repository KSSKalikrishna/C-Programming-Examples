#include<stdio.h>
#include<conio.h>
void main(){
    int i,num,a;
    printf("Enter the number:");
    scanf("%d",&num);
    for(i=1;i<=10;i++){
       a=num*i;
        printf("%d\n",a);
        getch();
         
        
    }
}