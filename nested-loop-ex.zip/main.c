#include<stdio.h>
#include<conio.h>

void main(){
    for(int j=1;j<=5;j++){
    for(int i = 1; i <= 5; i++){
        printf("*");
    
    }
    printf("\n");
  }
}