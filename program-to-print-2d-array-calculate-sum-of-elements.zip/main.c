#include <stdio.h>

void main() {
    int a[2][3], i, j, sum = 0;

    // Input 2D array elements
    for(i = 0; i < 2; i++) {
        for(j = 0; j < 3; j++) {
            printf("Enter element a[%d][%d]: ", i, j);
            scanf("%d", &a[i][j]);
        }
    }

    // Display elements and calculate sum
    printf("\nArray elements:\n");
    for(i = 0; i < 2; i++) {
        for(j = 0; j < 3; j++) {
            printf("%d\t", a[i][j]);
            sum += a[i][j];  // Adding each element to sum
        }
        printf("\n");
    }

    // Print sum
    printf("\nSum of all elements: %d\n", sum);
}
