#include<stdio.h>
void main(){
    int a[10];
    int even=0,odd=0,i;
    for(i=0;i<10;i++){
        printf("enter the numbers:");
        scanf("%d",&a[i]);
        if(a[i]%2==0)
        even=even+1;//even++
        else
        odd=odd+1;//odd++
     }
     printf("even num: %d",even);

     printf("\nodd num = %d",odd);
}