#include<stdio.h>
void main(){
    int marks[5];
    int sum=0,avg,i;
    for(i=0;i<5;i++){
        printf("enter the marks:");
        scanf("%d",&marks[i]);
    }
     for(i=0;i<5;i++){
         sum=sum+marks[i];
     }
     printf("%d",sum);

     printf("\navg = %d",sum/5);
}